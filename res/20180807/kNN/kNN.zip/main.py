#-*- coding:utf-8 -*-
import kNN
from numpy import *
import matplotlib.pyplot as plt
plt.rcParams['font.sans-serif']=['SimHei'] #用来正常显示中文标签
plt.rcParams['axes.unicode_minus']=False #用来正常显示负号

#kNN.py的路径
#sys.path.append("D:\python")

#（1）创建一个简单标签
group,labels = kNN.createDataSet()
print("group:\n",group,'\n')
print("labels:\n",labels,'\n')

#（2）kNN分类
print("与[0,0]最近的类别:\n",kNN.classify0([0,0],group,labels,3),'\n')

#（3）读数据，绘图
datingDataMat,datingLabels = kNN.file2matrix('datingTestSet2.txt')
#检查数据
#[3, 2, 1, 1, 1, 1, 3, 3, 1, 3, 1, 1, 2, 1, 1, 1, 1, 1, 2, 3]
print("测试读入的数据:\n",datingLabels[0:20],'\n')
fig = plt.figure()
ax = fig.add_subplot(111)
ax.scatter(datingDataMat[:,1],datingDataMat[:,2])
plt.xlabel('玩游戏所耗时间百分比')
plt.ylabel('每周吃冰激凌公升数')
plt.show()

#（4）采用不同色彩区分样本
fig = plt.figure()
ax = fig.add_subplot(111)
ax.scatter(datingDataMat[:,1],datingDataMat[:,2],
           15.0*array(datingLabels),15.0*array(datingLabels))
plt.xlabel('玩游戏所耗时间百分比')
plt.ylabel('每周吃冰激凌公升数')
plt.show()

#（5）分类器测试
kNN.datingClassTest()

#（6）分类器预测
#用户输入，反馈结果
#喜欢的人玩游戏所占时间百分比：10
#每年出差里程数：10000
#每周冰激凌公升数：0.5
#预测结果：small doses
kNN.classifyPerson()


#手写数字识别
#宽高32x32黑白图
#大约2000个训练集，900个测试集
kNN.handwritingClassTest()
#改变变量k的值，修改训练样本和数目都会对错误率产生影响
